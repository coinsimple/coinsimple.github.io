<div class="wrap">
    <h2>Transactions</h2>
    <?php if ($items && count($items) > 0): ?>
        <table class="widefat">
            <thead>
            <tr>
                <th>Order#</th>
                <th>Item</th>
                <th>Price</th>
                <th>Email</th>
                <th>Completed</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($items as $row): ?>
                <tr>
                    <td><?= $row->id; ?></td>
                    <td><?= $row->item; ?></td>
                    <td><?= $row->price; ?> <?= $row->currency; ?></td>
                    <td><?= $row->email; ?></td>
                    <td>
                        <?php
                        if ($row->completed) {
                            echo '<span class="cbadge completed">Completed</span>';
                        } else {
                            echo '<span class="cbadge notcompleted">Not Completed</span>';
                        }
                        ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="tablenav">
            <div class="tablenav-pages">
                <?php
                if ($pageCount > 0) {
                    echo "Page:";
                    for ($i = 1; $i <= $pageCount; $i++) {
                        if ($currentPage === $i) {
                            echo "<b>" . $i . "</b>";
                        } else {
                            echo '<a href="' . admin_url("admin.php?page=monero_transactions&pagenum=" . $i) . '">' . $i . '</a>';
                        }
                    }
                }
                ?>
            </div>
        </div>
    <?php else: ?>
        <p>
            It looks Like you have no transactions yet
        </p>
    <?php endif; ?>
</div>