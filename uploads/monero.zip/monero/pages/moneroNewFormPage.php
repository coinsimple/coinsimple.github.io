<div class="wrap">
    <h2>New Monero Form</h2>
    <form method="POST" action="<?= admin_url("admin.php?page=monero_menu"); ?>">
        <table class="form-table">
            <tr valign="top">
                <th scope="row">
                    <label for="formname">Form Name:</label>
                </th>
                <td>
                    <input id="formname" name="formname" maxlength="60" type="text" class="regular-text" required/>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="itemname">Item Name:</label>
                    <br /><span class="smalltext">(you can type <span class="urlstr">{{order}}</span> for the order number)</span>
                </th>
                <td>
                    <textarea name="itemname" id="itemname" class="large-text" required></textarea>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="itemdescription">Item Description:</label>
                </th>
                <td>
                    <textarea name="itemdescription" id="itemdescription" class="large-text" required></textarea>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="itemprice">Price:</label>
                </th>
                <td>
                    <input id="itemprice" name="itemprice" type="number" class="regular-text" step="0.01" required/>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="itemcurrency">Currency:</label>
                </th>
                <td>
                    <select id="itemcurrency" name="itemcurrency" required>
                        <option value="USD">USD ($)</option>
                        <option value="BTC">BTC (฿)</option>
                    </select>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="itememail">Include Email Form:</label>
                </th>
                <td>
                    <input id=itememail" name="itememail" type="checkbox"/>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="itemmessage">Email Message:</label>
                    <br /><span class="smalltext">(you can type <span class="urlstr">{{order}}</span> for the order number)</span>
                </th>
                <td>
                    <textarea name="itemmessage" id="itemmessage" class="large-text"></textarea>
                </td>
            </tr>
        </table>
        <p class="submit">
            <input type="submit" value="Create Form" class="button button-large button-primary" />
        </p>
    </form>
</div>
