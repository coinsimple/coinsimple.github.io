<div class="wrap">
    <h2>
        Admin Page
        <a href="<?= admin_url("admin.php?page=monero_new_form"); ?>" class="add-new-h2">
            Create a New Payment Form
        </a>
    </h2>
    <?php if ($updated) : ?>
        <div id="message" class="updated"><p>Your Form has been Updated.</p></div>
    <?php endif; ?>

    <?php if ($inserted) : ?>
        <div id="message" class="updated"><p>Your Form has been Added</p></div>
    <?php endif; ?>

    <?php if ($items && count($items) > 0): ?>
        <table class="widefat">
            <thead>
            <tr>
                <th>Title</th>
                <th>Item</th>
                <th>Description</th>
                <th>Price</th>
                <th>Include Email</th>
                <th>Open</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($items as $row): ?>
                <tr>
                    <td><?= $row->title; ?></td>
                    <td><?= $row->item; ?></td>
                    <td><?= $row->description; ?></td>
                    <td><?= $row->price; ?> <?= $row->currency; ?></td>
                    <td><?php echo ($row->email) ? "Yes" : "No"; ?></td>
                    <td><a href="<?= admin_url("admin.php?page=monero_edit_form&id=" . $row->id); ?>" class="button button-primary">Open</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>
            It looks Like you have no forms setup yet
        </p>
        <p>
            <a href="<?= admin_url("admin.php?page=monero_new_form"); ?>" class="button button-large button-primary">
                Click Here to Create a New Form
            </a>
        </p>
    <?php endif; ?>
</div>

