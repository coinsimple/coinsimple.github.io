<div class="wrap">
    <h2>Monero Settings</h2>
    <?php if ($posted): ?>
        <div id="message" class="updated"><p>Settings Successfully Saved. Callback URL => <strong><?php echo site_url("?monero_complete=1&monero_id=" . $cbv . "&monero_secret=" . $secret); ?></strong></p></div>
    <?php endif; ?>


    <form method="POST" action="<?= admin_url("admin.php?page=monero_settings"); ?>">
        <table class="form-table">
            <?php if ($cbv > -1): ?>
                <tr valign="top">
                    <th scope="row">
                        <label>Callback URI</label>
                    </th>
                    <td>
                        <b><?php echo site_url("?monero_complete=1&monero_id=" . $cbv . "&monero_secret=" . $secret); ?></b>
                    </td>
                </tr>
            <?php endif; ?>
            <tr valign="top">
                <th scope="row">
                    <label for="monero_provider">Bitcoin Processor</label>
                </th>
                <td>
                    <select id="monero_provider" name="monero_provider" required>
                        <option value="BIPS" <?php if ($provider === "BIPS") { echo 'selected="selected"'; } ?>>BIPS</option>
                        <option value="COINBASE" <?php if ($provider === "COINBASE") { echo 'selected="selected"'; } ?>>Coinbase</option>
                    </select>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="monero_token">API Token</label>
                </th>
                <td>
                    <input id="monero_token" name="monero_token" class="large-text" value="<?= $token; ?>" required/>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    <label for="monero_secret">Callback Secret</label>
                </th>
                <td>
                    <input id="monero_secret" name="monero_secret" class="large-text" value="<?= $secret; ?>" required/><br>
                    <span class="smalltext">(secret param for the url e.g. <span class="urlstr">"www.example.com/?phpcoinsecret=FSO24SNFHWE5KSI2O"</span>)</span>
                </td>
            </tr>

        </table>
        <p class="submit">
            <input type="submit" value="Save Settings" class="button button-large button-primary" />
        </p>
    </form>
</div>
