<?php

namespace PhpCoin;

interface PhpCoinInterface
{
    public function forCustomer($name);
    public function addItem($name, $price, $description);
    public function getInvoiceUrl();
    public function setCurrency($currency);
    public function setCustomField($name, $value);
    public function parseCallback();
}
