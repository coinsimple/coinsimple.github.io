<?php

namespace PhpCoin;

class CoinBaseCoin extends \PhpCoin\PhpCoin
{
    private $apikey;

    public function __construct($apikey)
    {
        $this->apikey = $apikey;
        parent::__construct();
    }

    public function getInvoiceUrl()
    {
        if (count($this->items) === 0) {
            return false;
        }
        if (!is_string($this->currency)) {
            $this->currency = "USD";
        }

        if (!is_string($this->customer)) {
            $this->customer = "";
        }

        if (!is_array($this->custom)) {
            $this->custom = array();
        }

        $price = 0;
        $item = array();
        $description = array();

        foreach ($this->items as $i) {
            if ($i["description"] && $i["description"] !== "") {
                array_push($description, $i["description"]);
            }
            array_push($item, $i["name"]);
            $price += $i["price"];
        }

        $item = implode(" | ", $item);
        $description = implode(" | ", $description);

        $curlh = curl_init("https://coinbase.com/api/v1/buttons");
        curl_setopt($curlh, CURLOPT_POST, true);
        curl_setopt($curlh, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curlh, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
        curl_setopt($curlh, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curlh, CURLOPT_SSLVERSION, 3);
        curl_setopt($curlh, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curlh, CURLOPT_SSL_VERIFYHOST, 2);

        $body = array(
            "api_key" => $this->apikey,
            "button" => array(
                "name" => $item,
                "description" => $description,
                "price_string" => strval($price),
                "price_currency_iso" => $this->currency,
                "custom" => json_encode($this->custom)
            )
        );
        curl_setopt($curlh, CURLOPT_POSTFIELDS, json_encode($body));
        $resp = json_decode(curl_exec($curlh));
        if ($resp->success) {
            return "https://coinbase.com/checkouts/" . $resp->button->code;
        } else {
            return false;
        }
    }

    public function parseCallback()
    {
        $data = json_decode(file_get_contents("php://input"));
        if (!is_null($data) && isset($data->order) && isset($data->order->status) && $data->order->status === "completed" && isset($data->order->custom)) {
            $data->order->custom = json_decode($data->order->custom);
            if (!is_null($data->order->custom)) {
                $resp = (object)array(
                    "id" => $data->order->custom->transactionid,
                    "shash" => $data->order->custom->shash
                );
                return $resp;
            }
        }
        return false;
    }
}
