<?php

namespace PhpCoin;

class BipsCoin extends \PhpCoin\PhpCoin
{
    private $apikey;

    public function __construct($apikey)
    {
        $this->apikey = $apikey;
        parent::__construct();
    }

    public function getInvoiceUrl()
    {
        if (count($this->items) === 0) {
            return false;
        }
        if (!is_string($this->currency)) {
            $this->currency = "USD";
        }

        if (!is_string($this->customer)) {
            $this->customer = "";
        }
        if (!is_array($this->custom)) {
            $this->custom = array();
        }

        $price = 0;
        $item = array();

        foreach ($this->items as $i) {
            $currentItem = "";
            if ($i["description"] && $i["description"] !== "") {
                $currentItem = $i["name"] . " - " . $i["description"];
            } else {
                $currentItem = $i["name"];
            }
            array_push($item, $currentItem);
            $price += $i["price"];
        }

        $item = implode(" | ", $item);

        $curlh = curl_init("https://bips.me/api/v1/invoice");
        curl_setopt($curlh, CURLOPT_POST, true);
        curl_setopt($curlh, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curlh, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curlh, CURLOPT_USERPWD, $this->apikey . ":");
        curl_setopt($curlh, CURLOPT_SSLVERSION, 3);
        curl_setopt($curlh, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curlh, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt(
            $curlh,
            CURLOPT_POSTFIELDS,
            array(
                "currency" => $this->currency,
                "price" => $price,
                "item" => $item,
                "custom" => json_encode($this->custom)
            )
        );
        $invoiceUrl = curl_exec($curlh);
        if ($invoiceUrl === "https://bips.me/invoice/error/error" || $invoiceUrl === "https://bips.me/invoice//error") {
            return false;
        }
        return $invoiceUrl;
    }

    public function parseCallback()
    {
        if (isset($_POST['custom']) && isset($_POST['status']) && is_array($_POST['custom']) && $_POST['status'] === "1") {
            $resp = (object)array(
                "id" => $_POST['custom']['transactionid'],
                "shash" => $_POST['custom']['shash']
            );
            return $resp;
        } else {
            return false;
        }
    }
}
