<?php

namespace PhpCoin;

abstract class PhpCoin implements \PhpCoin\PhpCoinInterface
{
    protected $customer;
    protected $items;
    protected $currency;
    protected $custom;

    public function __construct() {
        $this->customer = "";
        $this->items = array();
        $this->currency = "USD";
        $this->custom = array();
    }

    public function forCustomer($name)
    {
        if (is_string($name)) {
            $this->customer = $name;
        }
    }

    public function setCurrency($currency)
    {
        if (is_string($currency)) {
            $this->currency = $currency;
        }
    }

    public function setCustomField($name, $value)
    {
        if  (is_string($name)) {
            $this->custom[$name] = $value;
        }
    }

    public function addItem($name, $price, $description = "")
    {
        if (is_string($name) && $price) {
            array_push(
                $this->items,
                array(
                    "name" => $name,
                    "price" => $price,
                    "description" => $description
                )
            );
        }
    }
}
