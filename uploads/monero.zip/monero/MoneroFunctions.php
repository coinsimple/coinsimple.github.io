<?php

function setupMoneroDB(){
	global $wpdb; //Get DB object
	
	$formsTable = $wpdb->prefix . "monero_forms";
	$transactionsTable = $wpdb->prefix . "monero_transactions";
	$callbackURITable = $wpdb->prefix . "monero_callbacks";
	
	$formsSQL = "CREATE TABLE $formsTable (
  id INT NOT NULL AUTO_INCREMENT,
  title VARCHAR(60) NOT NULL,
  item TEXT NOT NULL,
  description TEXT DEFAULT '' NOT NULL,
  price FLOAT NOT NULL,
  currency VARCHAR(3) NOT NULL,
  email BOOLEAN NOT NULL,
  message TEXT DEFAULT '' NOT NULL,
  PRIMARY KEY (id)
  );";
  
    $transactionsSQL = "CREATE TABLE $transactionsTable (
  id INT NOT NULL AUTO_INCREMENT,
  email VARCHAR(120) DEFAULT '' NOT NULL,
  item TEXT NOT NULL,
  cbversion INT NOT NULL,
  price FLOAT NOT NULL,
  currency VARCHAR(3) NOT NULL,
  completed BOOLEAN NOT NULL,
  hash VARCHAR(128) NOT NULL,
  created DATETIME NOT NULL,
  message TEXT DEFAULT '' NOT NULL ,
  paid DATETIME,
  PRIMARY KEY (id)
  );";
  
    $callbackURISQL = "CREATE TABLE $callbackURITable (
  id INT NOT NULL AUTO_INCREMENT,
  secret VARCHAR(512) NOT NULL,
  service VARCHAR(20) NOT NULL,
  PRIMARY KEY (id)
  );";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta($formsSQL);
    dbDelta($transactionsSQL);
    dbDelta($callbackURISQL);

    add_option("monero_provider", "BIPS");
    add_option("monero_token", "");
    add_option("monero_secret", "");
    add_option("monero_cb_id", -1);
}

function moneroStylesheet() {
    wp_register_style('monerostyle', plugins_url('monero.css', __FILE__));
    wp_enqueue_style('monerostyle');
}

function registerMoneroMenuPages()
{
    add_menu_page("Monero", "Monero Forms", "manage_options", "monero_menu", "showMoneroForms", "", 61);
    add_submenu_page(null, "Create New Form", "New Form", "manage_options", "monero_new_form", "showMoneroNewFormPage");
    add_submenu_page(null, "Edit a Form", "Edit Form", "manage_options", "monero_edit_form", "showMoneroEditFormPage");
    add_submenu_page("monero_menu", "View Transactions", "Transactions", "manage_options", "monero_transactions", "showMoneroTransactionsPage");
    add_submenu_page("monero_menu", "Settings", "Settings", "manage_options", "monero_settings", "showMoneroSettingsPage");
}

function showMoneroForms()
{
    global $wpdb;

    //Banner Variables
    $updated = false;
    $inserted = false;

    if (
        isset($_POST['formname'])
        && isset($_POST['itemname'])
        && isset($_POST['itemdescription'])
        && isset($_POST['itemprice'])
        && isset($_POST['itemcurrency'])
        && is_string($_POST['formname']) && strlen($_POST['formname']) <= 60
        && is_string($_POST['itemname']) && is_string($_POST['itemname'])
        && is_numeric($_POST['itemprice'])
        && is_string($_POST['itemcurrency']) && strlen($_POST['itemcurrency']) <= 3
    ) {
        if (isset($_POST['itememail'])) {
            $_POST['itememail'] = 1;
        } else {
            $_POST['itememail'] = 0;
        }

        $_POST['itemmessage'] = (isset($_POST['itemmessage'])) ? $_POST['itemmessage'] : "";

        if (isset($_POST['itemid']) && is_numeric($_POST['itemid'])) {
            $wpdb->update(
                $wpdb->prefix . "monero_forms",
                array(
                    "title" => $_POST['formname'],
                    "item" => $_POST['itemname'],
                    "description" => $_POST['itemdescription'],
                    "price" => floatval($_POST['itemprice']),
                    "currency" => $_POST['itemcurrency'],
                    "email" => $_POST['itememail'],
                    "message" => $_POST['itemmessage']
                ),
                array("id" => intval($_POST['itemid'])),
                array(
                    '%s',
                    '%s',
                    '%s',
                    '%f',
                    '%s',
                    '%d',
                    '%s'
                ),
                array('%d')
            );
            $updated = true;
        } else {
            $wpdb->insert(
                $wpdb->prefix . "monero_forms",
                array(
                    "title" => $_POST['formname'],
                    "item" => $_POST['itemname'],
                    "description" => $_POST['itemdescription'],
                    "price" => floatval($_POST['itemprice']),
                    "currency" => $_POST['itemcurrency'],
                    "email" => $_POST['itememail'],
                    "message" => $_POST['itemmessage']
                ),
                array(
                    '%s',
                    '%s',
                    '%s',
                    '%f',
                    '%s',
                    '%d',
                    '%s'
                )
            );
            $inserted = true;
        }
    }

    $sql = "SELECT * FROM " . $wpdb->prefix . "monero_forms";
    $items = $wpdb->get_results($sql);
    require("pages/moneroFormsPage.php");
}

function showMoneroNewFormPage()
{
    require("pages/moneroNewFormPage.php");
}

function showMoneroEditFormPage()
{
    $notFoundHTML = '<div class="wrap">Form Not Found <a href="' . admin_url("admin.php?page=monero_menu") . '" class="button button-primary">Go Back</a></div>';
    if (isset($_GET['id']) && is_numeric($_GET['id'])) {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare( 'SELECT * FROM ' . $wpdb->prefix . 'monero_forms WHERE id = %d', intval($_GET['id'])));
        if ($row) {
            require("pages/moneroEditFormPage.php");
        } else {
            echo $notFoundHTML;
        }
    } else {
        echo $notFoundHTML;
    }
}

function showMoneroTransactionsPage()
{
    global $wpdb;
    $sql = "SELECT COUNT(*) FROM " . $wpdb->prefix . "monero_transactions";
    $totalCount = $wpdb->get_var($sql);
    $pageCount = floor(($totalCount / 10.0) + 0.9);

    $currentPage = 1;
    if (isset($_GET['pagenum']) && is_numeric($_GET['pagenum'])) {
        $currentPage = intval($_GET['pagenum']);
        if ($currentPage < 1) {
            $currentPage = 1;
        }
        if ($currentPage > $pageCount) {
            $currentPage = $pageCount;
        }
    }

    $offset = ($currentPage - 1) * 10;
    $sql = "SELECT * FROM " . $wpdb->prefix . "monero_transactions ORDER BY id DESC LIMIT " . $offset . ", 10";
    $items = $wpdb->get_results($sql);

    require("pages/moneroShowTransactionsPage.php");
}

function showMoneroSettingsPage(){
    $provider = get_option("monero_provider");
    $token = get_option("monero_token");
    $secret = get_option("monero_secret");
    $cbv = get_option("monero_cb_id");

    $posted = false;

    if (isset($_POST['monero_provider']) && isset($_POST['monero_token']) && isset($_POST['monero_secret'])
    && ($provider !== $_POST['monero_provider'] || $token !== $_POST['monero_token'] || $secret !== $_POST['monero_secret'])) {
        update_option("monero_provider", $_POST['monero_provider']);
        update_option("monero_token", $_POST['monero_token']);
        update_option("monero_secret", $_POST['monero_secret']);

        $provider = $_POST['monero_provider'];
        $token = $_POST['monero_token'];
        $secret = $_POST['monero_secret'];

        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . "monero_callbacks",
            array(
                "secret" => $secret,
                "service" => $provider
            ),
            array(
                '%s',
                '%s'
            )
        );

        $cbv = $wpdb->insert_id;
        update_option("monero_cb_id", $cbv);

        $posted = true;
    }


    require("pages/moneroSettingsPage.php");
}

function registerMoneroShortCode($a){
    if (is_array($a) && isset($a['form']) && get_option("monero_token") !== "") {

        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare( 'SELECT * FROM ' . $wpdb->prefix . 'monero_forms WHERE title = %s', $a['form']));

        if ($row) {
            $res = '<form action="#" method="POST">';
            $res .= '<input type="hidden" name="monero_button" value="' . $row->id . '" />';

            if ($row->email) {
                $res .= '<input class="emailfield" placeholder="Email" type="email" maxlength="120" id="monero_email" name="monero_email" required/>';
            }
            $title = (isset($a['text']) && is_string($a['text'])) ? $a['text'] : $row->title;
            $res .= '<input type="submit" value="' . $title . '" /></form>';
            return $res;
        }
    }
}

function moneroStartTransaction() {
    if (isset($_POST['monero_button']) && is_numeric($_POST['monero_button']) && get_option("monero_token") !== "") {

        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare( 'SELECT * FROM ' . $wpdb->prefix . 'monero_forms WHERE id = %d', intval($_POST['monero_button'])));

        if ($row && (!$row->email || isset($_POST['monero_email']))) {
            $email = ($row->email) ? $_POST['monero_email'] : "";
            $randomStuff = array(
                "time" => time(),
                "email" => $email,
                "random" => str_shuffle(get_option("monero_token"))
            );

            $hash = hash("sha512", json_encode($randomStuff) . get_option("monero_secret"));
            $date = date("Y-m-d H:i:s", time());

            $wpdb->insert(
                $wpdb->prefix . "monero_transactions",
                array(
                    "email" => $email,
                    "item" => $row->item,
                    "price" => $row->price,
                    "currency" => $row->currency,
                    "completed" => 0,
                    "hash" => $hash,
                    "created" => $date,
                    "cbversion" => get_option("monero_cb_id"),
                    "message" => $row->message
                ),
                array(
                    '%s',
                    '%s',
                    '%f',
                    '%s',
                    '%d',
                    '%s',
                    '%s',
                    '%d',
                    '%s'
                )
            );


            if (strpos($row->item, "{{order}}") !== false) {
                $row->item = str_replace("{{order}}", $wpdb->insert_id, $row->item);
                $wpdb->update($wpdb->prefix . "monero_transactions", array("item" => $row->item), array("id" => $wpdb->insert_id), array("%s"), array("%d"));
            }

            require('vendor/autoload.php');

            $pcoin = null;
            $provider = get_option("monero_provider");
            $token = get_option("monero_token");
            if ($provider === "BIPS") {
                $pcoin = new \PhpCoin\BipsCoin($token);
            } else if ($provider === "COINBASE") {
                $pcoin = new \PhpCoin\CoinBaseCoin($token);
            }
            $pcoin->addItem($row->item, $row->price, $row->description);
            $pcoin->setCurrency($row->currency);
            $pcoin->setCustomField("transactionid", $wpdb->insert_id);
            $pcoin->setCustomField("shash", $hash);
            $url = $pcoin->getInvoiceUrl();
            if ($url) {
                wp_redirect($url);
            } else {
                $wpdb->delete($wpdb->prefix . "monero_transactions", array("id" => $wpdb->insert_id), array("%d"));
            }
        }
    }
}

function moneroCompleteTransaction() {
    if (isset($_GET['monero_complete']) && $_GET['monero_complete'] === "1" && isset($_GET['monero_secret']) && isset($_GET['monero_id']) && is_numeric($_GET['monero_id'])) {

        global $wpdb;
        $callback = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . $wpdb->prefix . "monero_callbacks WHERE id = %d", array(intval($_GET['monero_id']))));

        if ($callback && $callback->secret === $_GET['monero_secret']) {
            require('vendor/autoload.php');

            $pcoin = null;
            $provider = $callback->service;

            if ($provider === "BIPS") {
                $pcoin = new \PhpCoin\BipsCoin("#");
            } else if ($provider === "COINBASE") {
                $pcoin = new \PhpCoin\CoinBaseCoin("#");
            }

            $properties = $pcoin->parseCallback();

            if ($properties) {
                $transaction = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM " . $wpdb->prefix . "monero_transactions WHERE id = %d AND hash = %s",
                    array(
                        $properties->id,
                        $properties->shash
                    )
                ));

                if ($transaction) {
                    $date = date("Y-m-d H:i:s", time());
                    $wpdb->update($wpdb->prefix . "monero_transactions", array("completed" => 1, "paid" => $date), array("id" => $transaction->id), array("%d", "%s"), array("%d"));

                    //Send Email
                    if ($transaction->email !== "" && $transaction->message !== "") {
                        mail($transaction->email, "Purchase Completed", str_replace("{{order}}", $transaction->id, $transaction->message));
                    }

                    do_action("monero_payment_completed", $transaction);
                } else {
                    moneroCallbackError();
                }
            } else {
                moneroCallbackError();
            }
        } else {
            moneroCallbackError();
        }
    }
}

function moneroCallbackError(){
    wp_die("The Callback Didn't Validate");
}