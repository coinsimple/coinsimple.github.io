<?php
/**
 * Plugin Name: monero
 * Plugin URI: http://monero.com
 * Description: Bitcoin payment manager for Worpress
 * Version: 0.1
 * Author: Gabriel Manricks
 * Author URI: gabrielmanricks.com
 */
 
 include "MoneroFunctions.php";

 //Setup DB & Options
 register_activation_hook(__FILE__, "setupMoneroDB");

 //Add Stylesheet to pages
 add_action('admin_enqueue_scripts', 'moneroStylesheet');
 add_action('wp_enqueue_scripts', 'moneroStylesheet');

 //Add Admin pages
 add_action('admin_menu', 'registerMoneroMenuPages');

 //Add Shortcode
 add_shortcode('monero', 'registerMoneroShortCode');

 //Add Handler to create a transaction
 add_action("wp", "moneroStartTransaction");

 //Add Handler to complete the transaction
 add_action("wp", "moneroCompleteTransaction");